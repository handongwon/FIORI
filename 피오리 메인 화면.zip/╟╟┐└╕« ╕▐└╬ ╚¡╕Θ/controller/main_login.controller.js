sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/m/MessageToast',
    "sap/ui/model/Filter"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageToast, Filter) {
        "use strict";

        return Controller.extend("vert.fiorisd01.controller.main_login", {
            onInit: function () {
                var oCarousel = this.byId("slide");
                setInterval(function() { oCarousel.next(); }, 5000);
                
                // setTimeout(function() { oCarousel.next(); }, 5000);
            },
            
            login: function() {
                var oDialog = this.getView().byId("helloDialog");
                var oText = this.getView().byId("id_login"),
                    oSignup = this.byId("signup");
                var oId   = this.getView().byId("show_login");
                var oUsername = this.getView().byId("username").getValue(),
                    oPassword = this.byId("password");

//---------------------------------------------------------------------------------------------

                var oModel = this.getView().getModel();

                oModel.read("/ClientSet('"+oUsername+"')", {
                    success: function(oData){

                        if (oPassword.getValue() === oData.Clntpw) {

                            oId.setText(oUsername);
                            oId.setVisible(true);
                            oDialog.close();
                            MessageToast.show("로그인 성공");
                            oText.setText("로그아웃");
                            oSignup.setText("My Page");
                        }
                        else {
                            oPassword.setValueState('Error');
                            // oPassword.setEnabled("False");
                        }     

                    }.bind(this),
                    error: function(oData){
                        MessageToast.show("아이디를 체크해주세요");
                    }
                })
//---------------------------------------------------------------------------------------------------------------------                
            },
            
            onPressLogin: function(oEvent) {
                var oDialog = this.getView().byId("helloDialog");
                var oText = this.getView().byId("id_login"),
                    oSignup = this.byId("signup");
                var oId   = this.getView().byId("show_login"),
                    oIDInput = this.getView().byId("username"),
                    oPassInput = this.getView().byId("password");

                if(oText.getText() === "로그인"){
                    oDialog.show();
                }
                else if(oText.getText() === "로그아웃") {
                    oText.setText("로그인");
                    oSignup.setText("회원가입")
                    oId.setVisible(false);
                    oId.setText("********")
                    oIDInput.setValue("");
                    oPassInput.setValue("");
                    oPassInput.setValueState("None");
                }
            },

            onPressSignUp: function() {
                var oDialog = this.getView().byId("helloDialog");
                var oText = this.getView().byId("id_login");
                var oId   = this.getView().byId("show_login");

                MessageToast.show("회원가입 탭을 선택했습니다.");
            },

            handleClose: function () {
                var oDialog = this.getView().byId("helloDialog");
                oDialog.close();
            },

            openStoreView: function (oEvent) {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

                oRouter.navTo("store_view", {});
            },

            openMainView: function (oEvent) {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    
                oRouter.navTo("Routemain_login", {});
            }
           
        });
    });