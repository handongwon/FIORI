sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/m/MessageToast',
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageToast, Fragment, JSONModel) {
        "use strict";

	return Controller.extend("vert.fiorisd01.controller.store_view", {
		
		onInit: function() {

 			// JSON 객체 선언
			 var oCrtData = {
                items: []
            };

            // JSON 모델 생성
            var oModel = new JSONModel(oCrtData);

            // 뷰에 모델 설정
            this.getView().setModel(oModel, "crtData");

			this._matcodMap = {
                "MVCTN001": "베르 토너",
                "MVCCM002": "베르 크림",
                "MVCAP003": "베르 앰플",
                "MVCSS004": "베르 썬크림",
                "MVCHC005": "베르 핸드크림",
                "MVCLB006": "베르 립밤",
                "MVCWTN001": "베르 클레르 토너",
                "MVCWCM002": "베르 클레르 크림",
                "MVCWAP003": "베르 클레르 앰플",
                "MVCWLB004": "베르 클레르 립밤",
                "MVFPTN001": "베르 퐁세 토너",
                "MVFPCM002": "베르 퐁세 크림",
                "MVFPAP003": "베르 퐁세 앰플",
                "MVPSTN001": "베르 폼므 토너",
                "MVPSCM002": "베르 폼므 크림",
                "MVPSAP003": "베르 폼므 앰플",
                "MVFATN001": "베르 포레 토너",
                "MVFACM002": "베르 포레 크림",
                "MVFAAP003": "베르 포레 앰플",
                "MVFASS004": "베르 포레 썬크림",
                "MVFAHC005": "베르 포레 핸드크림",
                "MVFALB006": "베르 포레 립밤",
                "MVFG001": "베르 프뤼 퍼퓸밤",
                "MVFG002": "베르 아르브 퍼퓸밤",
                "MVFG003": "베르 플뢰르 퍼퓸밤"
            };

            this._priceMap = {
                "MVCTN001" : "20,000",
                "MVCCM002" : "26,000",
                "MVCAP003" : "23,000",
                "MVCSS004" : "24,000",
                "MVCHC005" : "23,000",
                "MVCLB006" : "5,000",
                "MVCWTN001": "25,000",
                "MVCWCM002": "31,000",
                "MVCWAP003": "28,000",
                "MVCWLB004": "8,000",
                "MVFPTN001": "28,000",
                "MVFPCM002": "45,000",
                "MVFPAP003": "55,000",
                "MVPSTN001": "53,000",
                "MVPSCM002": "57,000",
                "MVPSAP003": "59,000",
                "MVFATN001": "65,000",
                "MVFACM002": "72,000",
                "MVFAAP003": "71,000",
                "MVFASS004": "55,000",
                "MVFAHC005": "48,000",
                "MVFALB006": "20,000",
                "MVFG001"  : "30,000",
                "MVFG002"  : "30,000",
                "MVFG003"  : "30,000"
            };

            this._iconMap = {
                "MVCTN001" : "/image/toner1.png",
                "MVCCM002" : "/image/cream1.png",
                "MVCAP003" : "/image/ample1.png",
                "MVCSS004" : "/image/suncream1.png",
                "MVCHC005" : "/image/handcream1.png",
                "MVCLB006" : "/image/lipbalm1.png",
                "MVCWTN001": "/image/toner2.png",
                "MVCWCM002": "/image/cream2.png",
                "MVCWAP003": "/image/ample2.png",
                "MVCWLB004": "/image/lipbalm2.png",
                "MVFPTN001": "/image/toner3.png",
                "MVFPCM002": "/image/cream3.png",
                "MVFPAP003": "/image/sample1.jpg",
                "MVPSTN001": "/image/sample1.jpg",
                "MVPSCM002": "/image/sample1.jpg",
                "MVPSAP003": "/image/sample1.jpg",
                "MVFATN001": "/image/sample1.jpg",
                "MVFACM002": "/image/sample1.jpg",
                "MVFAAP003": "/image/sample1.jpg",
                "MVFASS004": "/image/sample1.jpg",
                "MVFAHC005": "/image/sample1.jpg",
                "MVFALB006": "/image/sample1.jpg",
                "MVFG001"  : "/image/sample1.jpg",
                "MVFG002"  : "/image/sample1.jpg",
                "MVFG003"  : "/image/sample1.jpg"
            };

			 // Matcod 문자열 초기화
			 this._matcodString = "";
		},

		openStoreView: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("store_view", {});
		},

		openMainView: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("Routemain_login", {});
		},

		onPress: function (oEvent) {
            var sFullId = oEvent.getSource().getId();
            var sMatcod = sFullId.split("--").pop(); // 마지막 부분 추출

            // 매핑된 이름 가져오기
            var sName = this._matcodMap[sMatcod] || "Unknown";
            var sPrice = this._priceMap[sMatcod] || "Unknown";
            var sIcon = this._iconMap[sMatcod] || "Unknown";

            var oModel = this.getView().getModel("crtData");
            var oData = oModel.getData();

            // 항목이 이미 존재하는지 확인
            var existingItem = oData.items.find(item => item.Matcod === sMatcod);

            if (existingItem) {
                // 존재하면 Quan 증가
                existingItem.Quan += 1;
            } else {
                // 존재하지 않으면 새로운 항목 추가
                var newItem = { "Matcod": sMatcod, "Name": sName, "Quan": 1 , "Price": sPrice, "Icon":sIcon};
                oData.items.push(newItem);
            }

            // 모델 갱신
            oModel.setData(oData);
            MessageToast.show("장바구니 추가 완료");
			this._matcodString += sMatcod + "_";
        },

		onOpenPopover: function (oEvent) {
			var oButton = oEvent.getSource(),
				oView = this.getView();

			// create popover
			if (!this._pPopover) {
				this._pPopover = Fragment.load({
					id: oView.getId(),
					name: "vert.fiorisd01.view.popover",
					controller: this
				}).then(function(oPopover){
					oView.addDependent(oPopover);
					return oPopover;
				});
			}

			this._pPopover.then(function(oPopover){
				oPopover.openBy(oButton);
			});
		
		},

		onReset: function () {
            // JSON 객체 초기화
            var oCrtData = {
                items: []
            };

            // 모델 갱신
            var oModel = this.getView().getModel("crtData");
            oModel.setData(oCrtData);

            MessageToast.show("장바구니를 초기화");
        },

		onCreate: function () {

			MessageToast.show(this._matcodString);

			var oCrtData = {
                items: []
            };

            // 모델 갱신
            var oModel = this.getView().getModel("crtData");
            oModel.setData(oCrtData);
            
        },
		
	});
});